<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Pengguna extends Authenticatable
{
    protected $table = 'pengguna';
    protected $guard = 'pengguna';
    protected $fillable = [
        'email',
        'nama',
        'nip',
        'password',
        'unit_id',
        'role'
    ];
}
