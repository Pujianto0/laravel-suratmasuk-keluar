<html>
<head>
    <title>Manajemen Surat Masuk & Surat Keluar</title>
</head>
<body>
    <p>
        Hallo <b>{{ $nama }}</b>, <br />
        ada pemberitahuan surat masuk baru, silahkan dicek pada aplikasi.
    </p>
</body>
</html>
